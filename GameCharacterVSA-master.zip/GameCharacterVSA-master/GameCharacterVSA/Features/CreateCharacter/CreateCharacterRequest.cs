﻿namespace GameCharacterVSA.Features.CreateCharacter
{
    public class CreateCharacterRequest
    {
        public required string Name { get; set; }
        public required string Class { get; set; }
    }
}
